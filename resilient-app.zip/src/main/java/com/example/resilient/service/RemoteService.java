package com.example.resilient.service;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

@Service
public class RemoteService {

    @CircuitBreaker(name = "remoteService", fallbackMethod = "fallback")
    public CompletableFuture<String> getData() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Thread.sleep(3000);
            } catch (InterruptedException ignored) {}
            throw new RuntimeException("Simulated failure");
        });
    }

    public CompletableFuture<String> fallback(Throwable t) {
        return CompletableFuture.completedFuture("Fallback response due to: " + t.getMessage());
    }
}
