package com.example.resilient.service;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

@Service
public class RemoteService {

    @CircuitBreaker(name = "remoteService", fallbackMethod = "fallback")
    public CompletableFuture<String> getData() {
        return CompletableFuture.supplyAsync(() -> {
            System.out.println("Simulating failure...");
            throw new RuntimeException("Simulated failure");
        });
    }

    public CompletableFuture<String> fallback(Throwable t) {
        System.out.println("Fallback triggered: " + t.getMessage());
        return CompletableFuture.completedFuture("Fallback response due to: " + t.getMessage());
    }
}
