package com.example.resilient.controller;

import com.example.resilient.service.RemoteService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.CompletableFuture;

@RestController
public class ResilientController {

    private final RemoteService remoteService;

    public ResilientController(RemoteService remoteService) {
        this.remoteService = remoteService;
    }

    @GetMapping("/data")
    public CompletableFuture<String> getData() {
        return remoteService.getData();
    }
}
