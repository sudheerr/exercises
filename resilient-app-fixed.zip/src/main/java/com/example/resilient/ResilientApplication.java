package com.example.resilient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResilientApplication {
    public static void main(String[] args) {
        SpringApplication.run(ResilientApplication.class, args);
    }
}
